window.Verity = window.Verity || {};

const MAX_INTERCEPTED_SESSIONS = 8;
const TRACKING_PARAMS = new Set(["fbclid", "gclid", "mc_cid", "mc_eid", "ref", "ref_src"]);

// --- Session-aware intercepted citation cache (filled by MAIN-world interceptor.js) ---
window.Verity._interceptedSessions = window.Verity._interceptedSessions || [];

document.addEventListener("verity-generation-start", (e) => {
  const detail = e.detail || {};
  if (detail.sessionId == null) return;
  if (window.Verity.extractor) {
    window.Verity.extractor.beginInterceptedSession(detail.sessionId, detail.timestamp);
  }
});

document.addEventListener("verity-citations", (e) => {
  const detail = e.detail || {};
  if (!Array.isArray(detail.citations) || detail.sessionId == null) return;
  if (window.Verity.extractor) {
    window.Verity.extractor.storeInterceptedCitations(detail);
  }
});

window.Verity.extractor = {
  beginInterceptedSession(sessionId, timestamp) {
    const sessions = window.Verity._interceptedSessions;
    const existing = sessions.find((session) => session.id === sessionId);
    if (existing) {
      existing.startedAt = timestamp || existing.startedAt || Date.now();
      existing.updatedAt = Date.now();
      return existing;
    }

    const session = {
      id: sessionId,
      citations: [],
      startedAt: timestamp || Date.now(),
      updatedAt: timestamp || Date.now(),
      consumed: false,
    };
    sessions.push(session);
    this._trimInterceptedSessions();
    return session;
  },

  storeInterceptedCitations(detail) {
    const session = this.beginInterceptedSession(detail.sessionId, detail.timestamp);
    const wasConsumed = session.consumed;
    session.citations = Array.isArray(detail.citations) ? detail.citations.slice() : [];
    session.updatedAt = detail.timestamp || Date.now();
    session.consumed = wasConsumed;
    this._trimInterceptedSessions();
  },

  peekPendingInterceptedSession() {
    this._trimInterceptedSessions();
    return window.Verity._interceptedSessions.find(
      (session) => !session.consumed && Array.isArray(session.citations) && session.citations.length > 0
    ) || null;
  },

  claimPendingInterceptedSession() {
    const session = this.peekPendingInterceptedSession();
    if (!session) return null;
    session.consumed = true;
    session.updatedAt = Date.now();
    return session;
  },

  clearInterceptedSessions() {
    window.Verity._interceptedSessions = [];
  },

  _trimInterceptedSessions() {
    const now = Date.now();
    window.Verity._interceptedSessions = window.Verity._interceptedSessions
      .filter((session) => (now - (session.updatedAt || session.startedAt || 0)) < 30000)
      .slice(-MAX_INTERCEPTED_SESSIONS);
  },

  /**
   * Extract all sources (url, label, context) from a response element.
   * Uses intercepted API data as primary source, DOM extraction as fallback.
   */
  extractSources(element, interceptedSession) {
    const intercepted = this._getInterceptedCitations(element, interceptedSession);

    const pills = this._extractFromCitationPills(element);
    const anchors = this._extractFromAnchors(element);
    const bare = this._extractFromText(element, anchors);
    const footnotes = this._extractFromFootnotes(element);
    const citationEls = this._extractFromCitationElements(element);

    const domSources = [...pills, ...anchors, ...bare, ...footnotes, ...citationEls];
    const all = intercepted.length > 0
      ? [...intercepted, ...domSources]
      : domSources;

    return this._deduplicate(all);
  },

  _canonicalizeUrl(url) {
    const raw = typeof url === "string" ? url.trim() : "";
    if (!raw) return "";

    try {
      const parsed = new URL(raw);
      parsed.hash = "";
      parsed.protocol = parsed.protocol.toLowerCase();
      parsed.hostname = parsed.hostname.toLowerCase().replace(/^www\./, "");
      if (
        (parsed.protocol === "https:" && parsed.port === "443") ||
        (parsed.protocol === "http:" && parsed.port === "80")
      ) {
        parsed.port = "";
      }

      const path = parsed.pathname || "/";
      parsed.pathname = path !== "/" && path.endsWith("/") ? path.slice(0, -1) : path;

      const keptParams = [];
      for (const [key, value] of parsed.searchParams.entries()) {
        const lower = key.toLowerCase();
        if (lower.startsWith("utm_") || TRACKING_PARAMS.has(lower)) {
          continue;
        }
        keptParams.push([key, value]);
      }

      keptParams.sort((a, b) => {
        if (a[0] === b[0]) return a[1].localeCompare(b[1]);
        return a[0].localeCompare(b[0]);
      });

      parsed.search = "";
      for (const [key, value] of keptParams) {
        parsed.searchParams.append(key, value);
      }

      return parsed.toString();
    } catch {
      return raw;
    }
  },

  _buildSource(url, label, context, options = {}) {
    const source = {
      url: this._canonicalizeUrl(url),
      label: typeof label === "string" ? label.trim() : "",
      context: typeof context === "string" ? context.trim() : "",
    };

    source._contextQuality = options.contextQuality ?? this._inferContextQuality(source.context);
    return source;
  },

  _inferContextQuality(context) {
    const text = typeof context === "string" ? context.trim() : "";
    if (!text) return 0;
    if (text === "Source citation" || text === "Source citation from AI response") {
      return 0;
    }
    return 1;
  },

  _isDomainLabel(label, url) {
    const cleanLabel = (label || "").trim().toLowerCase();
    if (!cleanLabel) return true;
    try {
      const hostname = new URL(url).hostname.toLowerCase();
      const normalizedHost = hostname.replace(/^www\./, "");
      return cleanLabel === hostname || cleanLabel === normalizedHost;
    } catch {
      return false;
    }
  },

  _mergeSource(existing, candidate) {
    if ((!existing.label || this._isDomainLabel(existing.label, existing.url)) && candidate.label && !this._isDomainLabel(candidate.label, candidate.url)) {
      existing.label = candidate.label;
    }

    const existingQuality = existing._contextQuality ?? this._inferContextQuality(existing.context);
    const candidateQuality = candidate._contextQuality ?? this._inferContextQuality(candidate.context);
    const existingLength = (existing.context || "").trim().length;
    const candidateLength = (candidate.context || "").trim().length;

    if (
      candidateQuality > existingQuality ||
      (candidateQuality === existingQuality && candidateLength > existingLength)
    ) {
      existing.context = candidate.context;
      existing._contextQuality = candidateQuality;
    }

    return existing;
  },

  _extractFromAnchors(element) {
    const sources = [];
    const links = element.querySelectorAll('a[href]');
    for (const a of links) {
      let url = a.href;
      if (!url || !url.startsWith("http")) continue;
      const label = a.innerText.trim() || this._domainFromUrl(url);
      const context = this._getContextForNode(a, element);
      sources.push(this._buildSource(url, label, context));
    }
    return sources;
  },

  _extractFromText(element, existingAnchors) {
    const existingUrls = new Set(existingAnchors.map((s) => this._canonicalizeUrl(s.url)));
    const fullText = element.innerText || "";
    const urlRegex = /https?:\/\/[^\s<>"')\]]+/g;
    const sources = [];
    let match;
    while ((match = urlRegex.exec(fullText)) !== null) {
      let url = match[0].replace(/[.,;:!?)\]>]+$/, "");
      const canonicalUrl = this._canonicalizeUrl(url);
      if (existingUrls.has(canonicalUrl)) continue;
      const label = this._domainFromUrl(url);
      const context = this._getContextFromPosition(fullText, match.index, url);
      sources.push(this._buildSource(url, label, context));
      existingUrls.add(canonicalUrl);
    }
    return sources;
  },

  _getContextForNode(node, responseElement) {
    const maxContextChars = VERITY_CONFIG.maxContextChars || 400;
    const minContextChars = VERITY_CONFIG.minContextChars || 30;

    // Walk up to find a containing paragraph or list item
    let container = node.closest("p, li, div");
    if (container && container !== responseElement) {
      let text = container.innerText.trim();
      if (text.length >= minContextChars && text.length <= maxContextChars) return text;
      if (text.length > maxContextChars) return text.slice(0, maxContextChars);
    }
    // Fallback: get text around the link position in full response
    const fullText = responseElement.innerText || "";
    const linkText = node.innerText.trim();
    const pos = fullText.indexOf(linkText);
    if (pos >= 0) {
      return this._getContextFromPosition(fullText, pos, "");
    }
    // Last resort
    return node.innerText.trim() || "Source citation";
  },

  _getContextFromPosition(fullText, position, urlToRemove) {
    const maxContextChars = VERITY_CONFIG.maxContextChars || 400;
    const minContextChars = VERITY_CONFIG.minContextChars || 30;
    const start = Math.max(0, position - 150);
    const end = Math.min(fullText.length, position + 150);
    let context = fullText.slice(start, end).trim();
    if (urlToRemove) {
      context = context.replace(urlToRemove, "").trim();
    }
    // Clean up: try to start and end at sentence boundaries
    const firstDot = context.indexOf(". ");
    if (firstDot > 0 && firstDot < 30 && start > 0) {
      context = context.slice(firstDot + 2);
    }
    if (context.length > maxContextChars) context = context.slice(0, maxContextChars);
    if (context.length < minContextChars) {
      context = fullText.slice(start, Math.min(fullText.length, position + 300)).trim();
    }
    if (context.length > maxContextChars) context = context.slice(0, maxContextChars);
    if (context.length < minContextChars) context = "Source citation from AI response";
    return context;
  },

  _domainFromUrl(url) {
    try {
      const hostname = new URL(url).hostname.replace(/^www\./, "");
      return hostname;
    } catch {
      return url.slice(0, 40);
    }
  },

  // --- DOM fallback: ChatGPT citation pills ---

  _extractFromCitationPills(element) {
    const sources = [];
    // ChatGPT renders citation pills with data-testid="webpage-citation-pill"
    // Each pill contains a single <a> with the visible source URL.
    // For grouped citations ("+1"), only the first URL is in the DOM.
    const pills = element.querySelectorAll('[data-testid="webpage-citation-pill"] a[href]');
    for (const a of pills) {
      const url = a.href || a.getAttribute("alt") || "";
      if (!url || !url.startsWith("http")) continue;
      const label = a.innerText.trim() || this._domainFromUrl(url);
      const context = this._getContextForNode(a, element);
      sources.push(this._buildSource(url, label, context));
    }
    return sources;
  },

  // --- Intercepted API citation helpers ---

  _getInterceptedCitations(element, session) {
    const data = session && Array.isArray(session.citations) ? session.citations : [];
    if (data.length === 0) return [];

    const fullText = element.innerText || "";
    return data.map((c) => {
      const contextMatch = this._findContextForUrl(fullText, c.url, c.domain);
      return this._buildSource(
        c.url,
        c.title || c.domain || this._domainFromUrl(c.url),
        contextMatch.text,
        { contextQuality: contextMatch.quality }
      );
    });
  },

  _findContextForUrl(fullText, url, domain) {
    // Try to find the URL or domain in the response text for context
    const searchTerms = [url, domain].filter(Boolean);
    for (const term of searchTerms) {
      const pos = fullText.indexOf(term);
      if (pos >= 0) {
        return {
          text: this._getContextFromPosition(fullText, pos, ""),
          quality: 2,
        };
      }
    }
    // Fallback: use the beginning of the response
    if (fullText.length >= 30) {
      return {
        text: fullText.slice(0, 400).trim(),
        quality: 0,
      };
    }
    return {
      text: "Source citation from AI response",
      quality: 0,
    };
  },

  // --- DOM fallback: footnote lists ---

  _extractFromFootnotes(element) {
    const sources = [];
    // ChatGPT sometimes renders a numbered source list at the end
    const orderedLists = element.querySelectorAll("ol");
    for (const ol of orderedLists) {
      const items = ol.querySelectorAll("li");
      for (const li of items) {
        const links = li.querySelectorAll("a[href]");
        for (const a of links) {
          const url = a.href;
          if (!url || !url.startsWith("http")) continue;
          const label = a.innerText.trim() || this._domainFromUrl(url);
          const context = li.innerText.trim().slice(0, 400) || "Source citation";
          sources.push(this._buildSource(url, label, context));
        }
      }
    }
    return sources;
  },

  // --- DOM fallback: citation elements with data attributes ---

  _extractFromCitationElements(element) {
    const sources = [];

    // Check elements with data-href or data-url attributes
    const dataAttrSelectors = "[data-href], [data-url]";
    const elements = element.querySelectorAll(dataAttrSelectors);
    for (const el of elements) {
      const url = el.getAttribute("data-href") || el.getAttribute("data-url");
      if (!url || !url.startsWith("http")) continue;
      const label = el.innerText.trim() || this._domainFromUrl(url);
      const context = this._getContextForNode(el, element);
      sources.push(this._buildSource(url, label, context));
    }

    // Check preview card selectors from config
    if (typeof VERITY_CONFIG !== "undefined" && VERITY_CONFIG.previewCardSelectors) {
      for (const selector of VERITY_CONFIG.previewCardSelectors) {
        try {
          const cards = element.querySelectorAll(selector);
          for (const card of cards) {
            const a = card.querySelector("a[href]");
            if (!a) continue;
            const url = a.href;
            if (!url || !url.startsWith("http")) continue;
            const label = a.innerText.trim() || card.innerText.trim().slice(0, 80) || this._domainFromUrl(url);
            const context = card.innerText.trim().slice(0, 400) || "Source citation";
            sources.push(this._buildSource(url, label, context));
          }
        } catch {
          // Invalid selector — skip
        }
      }
    }

    return sources;
  },

  _deduplicate(sources) {
    const deduped = [];
    const byUrl = new Map();

    for (const source of sources) {
      const canonicalUrl = this._canonicalizeUrl(source.url);
      if (!canonicalUrl) continue;

      const normalized = {
        url: canonicalUrl,
        label: typeof source.label === "string" ? source.label.trim() : "",
        context: typeof source.context === "string" ? source.context.trim() : "",
        _contextQuality: source._contextQuality ?? this._inferContextQuality(source.context),
      };

      const existing = byUrl.get(canonicalUrl);
      if (!existing) {
        byUrl.set(canonicalUrl, normalized);
        deduped.push(normalized);
        continue;
      }

      this._mergeSource(existing, normalized);
    }

    return deduped.map(({ url, label, context }) => ({ url, label, context }));
  },

  /**
   * Get the user's most recent prompt.
   */
  extractPrompt(selectors) {
    const all = document.querySelectorAll(selectors.userMessage);
    const latest = all[all.length - 1];
    if (latest) return latest.innerText.trim();
    return "";
  },

  /**
   * Get the full AI response text, capped at maxChars.
   */
  extractResponse(element, maxChars) {
    return (element.innerText || "").trim().slice(0, maxChars || 8000);
  },
};
